---------------------------------------------------------------------------------------------------------------------------------------------------
Auteur: Coulom Damien
Objectif: Créer un fichier .zip contenant des données utiles pour faire du test avec de faux utilisateurs
---------------------------------------------------------------------------------------------------------------------------------------------------
Contenu :

data: Répertoire contenant un fichier .csv et un fichier .xlsx avec des données d'utilisateurs potentiels générés aléatoirement (nom,num de tel,...)
img: Répertoire contenant des fichiers .jpg d'images de profils générés aléatoirement (de 1.jpg,2.jpg,...,à 100.jpg)
---------------------------------------------------------------------------------------------------------------------------------------------------
Sources :

-https://minimaltoolkit.com/random-user-profile-image.html
-https://www.mobilefish.com/services/random_test_data_generator/random_test_data_generator.php
-https://www.calculator.net/random-number-generator.html
-https://hobbygenerator.com/
-https://www.rangen.co.uk/chars/appgen.php
-https://studyfied.com/tool/random-boolean-generator/